//
//  BE24TableViewController.swift
//  Bethere24
//
//  Created by Prbath Neranja on 9/24/16.
//  Copyright © 2016 BeThere24. All rights reserved.
//

import UIKit

class BE24TableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setupLayout()
    }

}
