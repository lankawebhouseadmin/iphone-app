//
//  BE24ScoreView.swift
//  Bethere24
//
//  Created by Prbath Neranja on 12/2/16.
//  Copyright © 2016 LankaWebHouse. All rights reserved.
//

import UIKit

class BE24ScoreView: BE24View {

    @IBOutlet weak var imgScore: UIImageView!
    @IBOutlet weak var imgScoreName: UIImageView!
    
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
